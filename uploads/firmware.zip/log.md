# Project Chinchilla Log
This is a log of everything that is being worked on in relation this unit.
Entries are not deleted and new entries are added at the top of the this file.
Try and keep this up to date; it will make writing individual and group reports
easier.

## example entry
Who is working on what. Current problems.
